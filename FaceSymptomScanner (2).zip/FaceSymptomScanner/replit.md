# Overview

This is a Face Symptom Scanner application built as a medical analysis tool for detecting skin conditions and abnormalities. The application allows users to upload facial images for diagnostic scanning using face detection technology. It's built with a modern full-stack architecture using React/TypeScript for the frontend, Express.js for the backend, and PostgreSQL with Drizzle ORM for data persistence.

The application presents a medical-themed interface with a dark color scheme and uses the face-api.js library for client-side face detection. It includes features for image upload, processing, and displaying mock diagnostic results with intentionally alarming messages for demonstration purposes.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development and building
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom medical-themed dark color scheme
- **State Management**: React Query (TanStack Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Face Detection**: face-api.js library loaded via CDN for browser-based face detection

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API structure with `/api` prefix routing
- **Development**: tsx for TypeScript execution in development
- **Production Build**: esbuild for server bundling

## Data Storage
- **Database**: PostgreSQL configured via DATABASE_URL environment variable
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: User authentication table with username/password fields
- **Connection**: Neon Database serverless driver for PostgreSQL connections
- **Migrations**: Drizzle Kit for database schema migrations

## Authentication & Session Management
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions
- **User Model**: Basic user entity with UUID primary keys and unique usernames

## External Dependencies

### Core Technologies
- **Neon Database**: Serverless PostgreSQL hosting via `@neondatabase/serverless`
- **face-api.js**: Browser-based face detection and analysis loaded from CDN
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect

### UI Framework Stack
- **Radix UI**: Comprehensive set of unstyled, accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Embla Carousel**: Touch-friendly carousel component
- **Recharts**: Chart library for data visualization components

### Development Tools
- **Vite**: Fast build tool with React plugin and runtime error overlay
- **Replit Integration**: Vite plugin for Replit environment compatibility with cartographer support
- **TypeScript**: Strict type checking with path aliases for clean imports

### Form & Validation
- **React Hook Form**: Performant forms with minimal re-renders
- **Zod**: TypeScript-first schema validation integrated with Drizzle
- **Hookform Resolvers**: Zod integration for React Hook Form validation

The application follows a monorepo structure with shared types and schemas, clean separation between client and server code, and a modern development workflow optimized for the Replit environment.